import { getStore } from "@netlify/blobs";

export default async (req, context) => {
  const headers = { "Content-Type": "application/json" };
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const body = await req.json();
    const { action, playerId, type, player } = body;

    const store = getStore({ name: "padel-data", consistency: "strong" });
    const data = await store.get("gamedata", { type: "json" });
    if (!data) return new Response(JSON.stringify({ error: "No data" }), { status: 404, headers });

    if (action === "increment" || action === "decrement") {
      if (!data.scores[playerId]) data.scores[playerId] = { koning: 0, nosso: 0, gamesPlayed: 0 };
      const delta = action === "increment" ? 1 : -1;
      data.scores[playerId][type] = Math.max(0, (data.scores[playerId][type] || 0) + delta);
    }

    if (action === "increment_games" || action === "decrement_games") {
      if (!data.scores[playerId]) data.scores[playerId] = { koning: 0, nosso: 0, gamesPlayed: 0 };
      const delta = action === "increment_games" ? 1 : -1;
      data.scores[playerId].gamesPlayed = Math.max(0, (data.scores[playerId].gamesPlayed || 0) + delta);
    }

    if (action === "add_player") {
      const newId = player.name.toLowerCase().replace(/\s+/g, "_") + "_" + Date.now();
      data.players.push({ id: newId, name: player.name, nickname: player.nickname });
      data.scores[newId] = { koning: 0, nosso: 0, gamesPlayed: 0 };
    }

    if (action === "remove_player") {
      data.players = data.players.filter(p => p.id !== playerId);
      delete data.scores[playerId];
    }

    if (action === "edit_player") {
      const idx = data.players.findIndex(p => p.id === playerId);
      if (idx >= 0) data.players[idx] = { ...data.players[idx], ...player };
    }

    await store.setJSON("gamedata", data);
    return new Response(JSON.stringify(data), { status: 200, headers });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
  }
};
