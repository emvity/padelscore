import { getStore } from "@netlify/blobs";

const SEASON_CALENDAR = [
  { season: 1, start: "2025-01-01",  end: "2026-03-19", prize: "BBQ Organiseren 🔥" },
  { season: 2, start: "2026-03-19",  end: "2026-06-21", prize: "Daydrink Dag Organiseren 🍻" },
  { season: 3, start: "2026-06-21",  end: "2026-09-23", prize: "Daydrink Dag Organiseren 🍻" },
  { season: 4, start: "2026-09-23",  end: "2026-12-21", prize: "Daydrink Dag Organiseren 🍻" },
  { season: 5, start: "2026-12-21",  end: "2027-03-21", prize: "Daydrink Dag Organiseren 🍻" },
];

const PLAYERS = [
  { id: "max",     name: "Max",     nickname: "Poeky" },
  { id: "samuel",  name: "Samuel",  nickname: "BigmacSamu" },
  { id: "jurjen",  name: "Jurjen",  nickname: "BurryBalzak" },
  { id: "roan",    name: "Roan",    nickname: "Rocky" },
  { id: "maarten", name: "Maarten", nickname: "Mr. Orgasm" },
  { id: "nick",    name: "Nick",    nickname: "Einstein" },
  { id: "rik",     name: "Rik",     nickname: "Rich Rickgga" },
  { id: "stijn",   name: "Stijn",   nickname: "Lotteveltkamp" },
  { id: "tijn",    name: "Tijn",    nickname: "TonnoTijn" },
];

const SEASON_1_SCORES = {
  max:     { koning: 0,  nosso: 2, gamesPlayed: 0 },
  samuel:  { koning: 4,  nosso: 0, gamesPlayed: 0 },
  jurjen:  { koning: 0,  nosso: 3, gamesPlayed: 0 },
  roan:    { koning: 9,  nosso: 1, gamesPlayed: 0 },
  maarten: { koning: 5,  nosso: 2, gamesPlayed: 0 },
  nick:    { koning: 14, nosso: 1, gamesPlayed: 0 },
  rik:     { koning: 1,  nosso: 5, gamesPlayed: 0 },
  stijn:   { koning: 0,  nosso: 1, gamesPlayed: 0 },
  tijn:    { koning: 1,  nosso: 1, gamesPlayed: 0 },
};

function buildSeason1Archive(liveScores) {
  const scores = liveScores || SEASON_1_SCORES;
  const ranking = PLAYERS.map(p => ({
    id: p.id, name: p.name, nickname: p.nickname,
    koning: scores[p.id]?.koning || 0,
    nosso:  scores[p.id]?.nosso  || 0,
    gamesPlayed: scores[p.id]?.gamesPlayed || 0,
  })).sort((a, b) => b.nosso - a.nosso);
  const w = ranking[0];
  return {
    season: 1, startDate: "2025-01-01", endDate: "2026-03-19",
    prize: "BBQ Organiseren 🔥", scores,
    winner: { id: w.id, name: w.name, nickname: w.nickname, nosso: w.nosso, prize: "BBQ Organiseren 🔥" },
    finalRanking: ranking,
  };
}

export default async (req, context) => {
  const headers = { "Content-Type": "application/json" };
  try {
    const store = getStore({ name: "padel-data", consistency: "strong" });
    let data = await store.get("gamedata", { type: "json" });

    if (!data || data.season === 1) {
      data = {
        season: 2,
        seasonStartDate: "2026-03-19",
        seasonEndDate: "2026-06-21",
        prize: "Daydrink Dag Organiseren 🍻",
        players: PLAYERS,
        scores: Object.fromEntries(PLAYERS.map(p => [p.id, { koning: 0, nosso: 0, gamesPlayed: 0 }])),
        history: [buildSeason1Archive(data?.scores || null)],
        calendar: SEASON_CALENDAR,
      };
      await store.setJSON("gamedata", data);
    }

    // Backfill gamesPlayed indien ontbrekend
    let needsSave = false;
    for (const p of (data.players || [])) {
      if (data.scores[p.id] && data.scores[p.id].gamesPlayed === undefined) {
        data.scores[p.id].gamesPlayed = 0;
        needsSave = true;
      }
    }

    // Automatische seizoenswissel
    if (new Date() >= new Date(data.seasonEndDate)) {
      const cur  = SEASON_CALENDAR.find(s => s.season === data.season);
      const next = SEASON_CALENDAR.find(s => s.season === data.season + 1);
      if (next) {
        const ranking = data.players.map(p => ({
          id: p.id, name: p.name, nickname: p.nickname,
          koning: data.scores[p.id]?.koning || 0,
          nosso:  data.scores[p.id]?.nosso  || 0,
          gamesPlayed: data.scores[p.id]?.gamesPlayed || 0,
        })).sort((a, b) => b.nosso - a.nosso);
        const w = ranking[0];
        data = {
          season: next.season,
          seasonStartDate: next.start,
          seasonEndDate: next.end,
          prize: next.prize,
          players: data.players,
          scores: Object.fromEntries(data.players.map(p => [p.id, { koning: 0, nosso: 0, gamesPlayed: 0 }])),
          history: [...(data.history || []), {
            season: data.season,
            startDate: data.seasonStartDate,
            endDate: data.seasonEndDate,
            prize: cur?.prize || "🏆",
            scores: { ...data.scores },
            winner: { id: w.id, name: w.name, nickname: w.nickname, nosso: w.nosso, prize: cur?.prize || "🏆" },
            finalRanking: ranking,
          }],
          calendar: SEASON_CALENDAR,
        };
        await store.setJSON("gamedata", data);
      }
    } else if (needsSave) {
      await store.setJSON("gamedata", data);
    }

    if (!data.calendar) data.calendar = SEASON_CALENDAR;
    return new Response(JSON.stringify(data), { status: 200, headers });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
  }
};
