export default async (req, context) => {
  const headers = { "Content-Type": "application/json" };
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const { player, type } = await req.json();
    const phone  = Netlify.env.get("CALLMEBOT_PHONE");
    const apikey = Netlify.env.get("CALLMEBOT_APIKEY");

    if (!phone || !apikey) {
      return new Response(JSON.stringify({ error: "Missing env vars" }), { status: 500, headers });
    }

    const emoji = type === "koning" ? "👑" : "💀";
    const label = type === "koning" ? "Koning punt" : "Nosso punt";
    const msg   = `${emoji} ${player} heeft een ${label} gescoord! scorepadel.netlify.app`;
    const url   = `https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${encodeURIComponent(msg)}&apikey=${apikey}`;

    const res  = await fetch(url);
    const text = await res.text();

    return new Response(JSON.stringify({ ok: true, response: text }), { status: 200, headers });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
  }
};
